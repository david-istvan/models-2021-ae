# INSTALL

 - Download the `R` installer from https://www.r-project.org/ and run it.
 - Download the `R Studio` installer from https://www.rstudio.com/products/rstudio/download/ and run it.