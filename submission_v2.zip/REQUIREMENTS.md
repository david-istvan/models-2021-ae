# REQUIREMENTS

 - Requirements for running the analysis scripts:
   - `R version 4.0.2 (2020-06-22)`.
   - `R Studio Version 1.3.1073`.